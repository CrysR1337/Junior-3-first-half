# VM-simulator

Virtual Memory simulator, with directory and table indexing and paging. Also includes replacement algorithms (Rand, FIFO, CLOCK, LRU and OPT) used by the VM
